# python sumar-tradus-t5.py >sumar-tradus-germana-t5.txt
# scrie rezultatul sumarului in fisierul  sumar-tradus-germana-t5.txt
# https://www.thepythoncode.com/article/text-summarization-using-huggingface-transformers-python

#utilizare T5
# SentencePiece library
# pip install sentencepiece
from transformers import T5ForConditionalGeneration, T5Tokenizer
# initialize the model architecture and weights
model = T5ForConditionalGeneration.from_pretrained("t5-base")
# initialize the model tokenizer
tokenizer = T5Tokenizer.from_pretrained("t5-base")

article = """
New research shows that analysing someone’s communication type and parroting it back may make you more persuasive.
Everyone knows that currying favour is harder than it looks. Getting someone on your side – whether it’s during a presentation or pitch, or simply trying to wow during a social interaction – is a nerve-wracking process. Do they like me? Do they agree with what I think? Am I even making sense? 
But cracking the secret to connecting with someone may actually be easier than it seems: simply, copy them.
We already know mimicking body language, expression and gestures can help people forge relationships, but results from a new organisational-behaviour study indicate that imitating someone’s communication style can also make you more persuasive. The parroting technique is called ‘linguistic mirroring’, and data shows that implementing the strategy can boost the efficacy of your message.
For example, the next time you’re on that Zoom all-staff meeting, pay close attention to how each of your colleagues speak and present their thoughts. Some might only be concerned with fast data points and bottom lines, acting brusque and maybe even a bit standoffish. Others may be far less linear, and might launch into a rambling story. The research shows you should adjust your speech to mimic them – even if their communication style is miles from your own.
"""
# encode the text into tensor of integers using the appropriate tokenizer
inputs = tokenizer.encode("translate English to German: " + article, return_tensors="pt", max_length=512, truncation=True)

# tokenizer.encode() method convert string text to a list of integers, where each integer is a unique token.

# set max_length to 512, original text not to bypass 512 tokens
# set return_tensors to "pt" to get PyTorch tensors as output.

# we prepended the text with "summarize: " text, and that's because T5 isn't just for text summarization, you can basically use it for any text-to-text transformation, such as machine translation or question answering.

# ex. T5 transformer can be used for machine translation, you can set "translate English to German: " instead of "summarize: " and you'll get a German translation output (more precisely, you'll get a summarized German translation, as you'll see why in model.generate()).

# generate the summarization output
outputs = model.generate(
    inputs, 
    max_length=150, 
    min_length=40, 
    length_penalty=2.0, 
    num_beams=4, 
    early_stopping=True)
# just for debugging
print(outputs)
print(tokenizer.decode(outputs[0]))

