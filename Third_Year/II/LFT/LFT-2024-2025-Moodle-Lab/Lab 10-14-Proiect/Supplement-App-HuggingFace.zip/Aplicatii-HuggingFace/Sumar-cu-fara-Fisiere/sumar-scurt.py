# python sumar-scurt.py >sumar-articol-scurt.txt
# scrie rezultatul sumarului in fisierul sumar-articol-scurt.txt
# https://www.thepythoncode.com/article/text-summarization-using-huggingface-transformers-python

from transformers import pipeline
# using pipeline API for summarization task
summarization = pipeline("summarization")
original_text = """
New research shows that analysing someone’s communication type and parroting it back may make you more persuasive.
Everyone knows that currying favour is harder than it looks. Getting someone on your side – whether it’s during a presentation or pitch, or simply trying to wow during a social interaction – is a nerve-wracking process. Do they like me? Do they agree with what I think? Am I even making sense?
But cracking the secret to connecting with someone may actually be easier than it seems: simply, copy them.
We already know mimicking body language, expression and gestures can help people forge relationships, but results from a new organisational-behaviour study indicate that imitating someone’s communication style can also make you more persuasive. The parroting technique is called ‘linguistic mirroring’, and data shows that implementing the strategy can boost the efficacy of your message.
For example, the next time you’re on that Zoom all-staff meeting, pay close attention to how each of your colleagues speak and present their thoughts. Some might only be concerned with fast data points and bottom lines, acting brusque and maybe even a bit standoffish. Others may be far less linear, and might launch into a rambling story. The research shows you should adjust your speech to mimic them – even if their communication style is miles from your own.
"""
summary_text = summarization(original_text)[0]['summary_text']
print("Summary:", summary_text) 
