from transformers import pipeline
# Deschidere si citire "r" (read) articole 
f = open("article.txt", "r", encoding="utf8")
to_tokenize = f.read()
# Initializare HuggingFace summarization pipeline
summarizer = pipeline("summarization")
sumar = summarizer(to_tokenize, min_length=75, max_length=300)
# Afisare sumar
print(sumar)
